A sample flex/bison parser for a toy assembly-like language. The
`sample.asm` file contains the description of the language itself,
and the lexer and parser sources are commented throughout. The rest
should be reasonably self-explanatory.
