﻿namespace client
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.textBox_ip = new System.Windows.Forms.TextBox();
			this.textBox_port = new System.Windows.Forms.TextBox();
			this.button_connect = new System.Windows.Forms.Button();
			this.logs = new System.Windows.Forms.RichTextBox();
			this.textBox_message = new System.Windows.Forms.TextBox();
			this.button_send = new System.Windows.Forms.Button();
			this.button_disconnect = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.box9 = new System.Windows.Forms.Label();
			this.box8 = new System.Windows.Forms.Label();
			this.box7 = new System.Windows.Forms.Label();
			this.box6 = new System.Windows.Forms.Label();
			this.box5 = new System.Windows.Forms.Label();
			this.box4 = new System.Windows.Forms.Label();
			this.box3 = new System.Windows.Forms.Label();
			this.box2 = new System.Windows.Forms.Label();
			this.box1 = new System.Windows.Forms.Label();
			this.textBox_name = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(44, 81);
			this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(20, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "IP:";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(34, 108);
			this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(29, 13);
			this.label2.TabIndex = 1;
			this.label2.Text = "Port:";
			// 
			// textBox_ip
			// 
			this.textBox_ip.Location = new System.Drawing.Point(67, 79);
			this.textBox_ip.Margin = new System.Windows.Forms.Padding(2);
			this.textBox_ip.Name = "textBox_ip";
			this.textBox_ip.Size = new System.Drawing.Size(88, 20);
			this.textBox_ip.TabIndex = 2;
			// 
			// textBox_port
			// 
			this.textBox_port.Location = new System.Drawing.Point(67, 108);
			this.textBox_port.Margin = new System.Windows.Forms.Padding(2);
			this.textBox_port.Name = "textBox_port";
			this.textBox_port.Size = new System.Drawing.Size(88, 20);
			this.textBox_port.TabIndex = 3;
			// 
			// button_connect
			// 
			this.button_connect.Location = new System.Drawing.Point(37, 142);
			this.button_connect.Margin = new System.Windows.Forms.Padding(2);
			this.button_connect.Name = "button_connect";
			this.button_connect.Size = new System.Drawing.Size(70, 22);
			this.button_connect.TabIndex = 4;
			this.button_connect.Text = "Connect";
			this.button_connect.UseVisualStyleBackColor = true;
			this.button_connect.Click += new System.EventHandler(this.button_connect_Click);
			// 
			// logs
			// 
			this.logs.Location = new System.Drawing.Point(541, 51);
			this.logs.Margin = new System.Windows.Forms.Padding(2);
			this.logs.Name = "logs";
			this.logs.Size = new System.Drawing.Size(192, 261);
			this.logs.TabIndex = 5;
			this.logs.Text = "";
			// 
			// textBox_message
			// 
			this.textBox_message.Enabled = false;
			this.textBox_message.Location = new System.Drawing.Point(67, 275);
			this.textBox_message.Margin = new System.Windows.Forms.Padding(2);
			this.textBox_message.Name = "textBox_message";
			this.textBox_message.Size = new System.Drawing.Size(98, 20);
			this.textBox_message.TabIndex = 6;
			// 
			// button_send
			// 
			this.button_send.Enabled = false;
			this.button_send.Location = new System.Drawing.Point(166, 269);
			this.button_send.Margin = new System.Windows.Forms.Padding(2);
			this.button_send.Name = "button_send";
			this.button_send.Size = new System.Drawing.Size(65, 26);
			this.button_send.TabIndex = 8;
			this.button_send.Text = "Send";
			this.button_send.UseVisualStyleBackColor = true;
			this.button_send.Click += new System.EventHandler(this.button_send_Click);
			// 
			// button_disconnect
			// 
			this.button_disconnect.Enabled = false;
			this.button_disconnect.Location = new System.Drawing.Point(111, 142);
			this.button_disconnect.Margin = new System.Windows.Forms.Padding(2);
			this.button_disconnect.Name = "button_disconnect";
			this.button_disconnect.Size = new System.Drawing.Size(70, 22);
			this.button_disconnect.TabIndex = 15;
			this.button_disconnect.Text = "Disconnect";
			this.button_disconnect.UseVisualStyleBackColor = true;
			this.button_disconnect.Click += new System.EventHandler(this.button_disconnect_Click);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(10, 276);
			this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(32, 13);
			this.label3.TabIndex = 7;
			this.label3.Text = "Turn:";
			// 
			// box9
			// 
			this.box9.AutoSize = true;
			this.box9.Location = new System.Drawing.Point(402, 195);
			this.box9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.box9.Name = "box9";
			this.box9.Size = new System.Drawing.Size(13, 13);
			this.box9.TabIndex = 33;
			this.box9.Text = "9";
			// 
			// box8
			// 
			this.box8.AutoSize = true;
			this.box8.Location = new System.Drawing.Point(367, 195);
			this.box8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.box8.Name = "box8";
			this.box8.Size = new System.Drawing.Size(13, 13);
			this.box8.TabIndex = 32;
			this.box8.Text = "8";
			// 
			// box7
			// 
			this.box7.AutoSize = true;
			this.box7.Location = new System.Drawing.Point(330, 195);
			this.box7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.box7.Name = "box7";
			this.box7.Size = new System.Drawing.Size(13, 13);
			this.box7.TabIndex = 31;
			this.box7.Text = "7";
			// 
			// box6
			// 
			this.box6.AutoSize = true;
			this.box6.Location = new System.Drawing.Point(402, 173);
			this.box6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.box6.Name = "box6";
			this.box6.Size = new System.Drawing.Size(13, 13);
			this.box6.TabIndex = 30;
			this.box6.Text = "6";
			// 
			// box5
			// 
			this.box5.AutoSize = true;
			this.box5.Location = new System.Drawing.Point(367, 173);
			this.box5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.box5.Name = "box5";
			this.box5.Size = new System.Drawing.Size(13, 13);
			this.box5.TabIndex = 29;
			this.box5.Text = "5";
			// 
			// box4
			// 
			this.box4.AutoSize = true;
			this.box4.Location = new System.Drawing.Point(330, 173);
			this.box4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.box4.Name = "box4";
			this.box4.Size = new System.Drawing.Size(13, 13);
			this.box4.TabIndex = 28;
			this.box4.Text = "4";
			// 
			// box3
			// 
			this.box3.AutoSize = true;
			this.box3.Location = new System.Drawing.Point(402, 151);
			this.box3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.box3.Name = "box3";
			this.box3.Size = new System.Drawing.Size(13, 13);
			this.box3.TabIndex = 27;
			this.box3.Text = "3";
			// 
			// box2
			// 
			this.box2.AutoSize = true;
			this.box2.Location = new System.Drawing.Point(367, 151);
			this.box2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.box2.Name = "box2";
			this.box2.Size = new System.Drawing.Size(13, 13);
			this.box2.TabIndex = 26;
			this.box2.Text = "2";
			// 
			// box1
			// 
			this.box1.AutoSize = true;
			this.box1.Location = new System.Drawing.Point(330, 151);
			this.box1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.box1.Name = "box1";
			this.box1.Size = new System.Drawing.Size(13, 13);
			this.box1.TabIndex = 25;
			this.box1.Text = "1";
			// 
			// textBox_name
			// 
			this.textBox_name.Location = new System.Drawing.Point(67, 51);
			this.textBox_name.Margin = new System.Windows.Forms.Padding(2);
			this.textBox_name.Name = "textBox_name";
			this.textBox_name.Size = new System.Drawing.Size(88, 20);
			this.textBox_name.TabIndex = 34;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(26, 54);
			this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(38, 13);
			this.label4.TabIndex = 35;
			this.label4.Text = "Name:";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(744, 358);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.textBox_name);
			this.Controls.Add(this.box9);
			this.Controls.Add(this.box8);
			this.Controls.Add(this.box7);
			this.Controls.Add(this.box6);
			this.Controls.Add(this.box5);
			this.Controls.Add(this.box4);
			this.Controls.Add(this.box3);
			this.Controls.Add(this.box2);
			this.Controls.Add(this.box1);
			this.Controls.Add(this.button_disconnect);
			this.Controls.Add(this.button_send);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.textBox_message);
			this.Controls.Add(this.logs);
			this.Controls.Add(this.button_connect);
			this.Controls.Add(this.textBox_port);
			this.Controls.Add(this.textBox_ip);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Margin = new System.Windows.Forms.Padding(2);
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_ip;
        private System.Windows.Forms.TextBox textBox_port;
        private System.Windows.Forms.Button button_connect;
        private System.Windows.Forms.RichTextBox logs;
        private System.Windows.Forms.TextBox textBox_message;
        private System.Windows.Forms.Button button_send;
		private System.Windows.Forms.Button button_disconnect;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label box9;
		private System.Windows.Forms.Label box8;
		private System.Windows.Forms.Label box7;
		private System.Windows.Forms.Label box6;
		private System.Windows.Forms.Label box5;
		private System.Windows.Forms.Label box4;
		private System.Windows.Forms.Label box3;
		private System.Windows.Forms.Label box2;
		private System.Windows.Forms.Label box1;
		private System.Windows.Forms.TextBox textBox_name;
		private System.Windows.Forms.Label label4;
	}
}

